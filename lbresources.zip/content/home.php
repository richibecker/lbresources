
<div class="main zerogrid">
<!-- home content -->
	<article id="content">
			<div class="wrapper row" style="">
				<section class="col-3-4">
					<div class="wrap-col">
						<h2 class="under">Expertise in Execution of Businesses - Converting Plans to Reality!</h2>

						<div class="wrapper">
							<figure class="left marg_right1"><img src="images/page1_img1.jpg" alt=""></figure>
							<p class="pad_bot1">bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla </p>
							<p>
									bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla
                                  bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla
                                  bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla
                                    <a href="#"class="link1">Read More</a></p>
						</div>

                        <!--
						<div class="container">
						<video  width="645" height="307" poster="images/video-poster.jpg" >
						<source  src="video/movie.webm" type="video/webm">-->
						<!-- klo gak support jadi ke youtube -->
						 <!--<embed width="645" height="307" src="http://www.youtube.com/v/XGSy3_Czz8k">
						</video>
						</div>-->

					</div>
				</section>
				<section class="col-1-4">
					<div class="wrap-col">
						<h2>News</h2>
						<div class="testimonials">
						<div id="testimonials">
						  <ul>
							<li>
								<div>
									bla bla bla bla bla bla bla bla bla bla bla bla
									<a href="#"class="link1">Read More</a>
								</div>
								<span><strong class="color1">New Title 1</strong> <br>
								October 20, 2014</span>
							</li>
							<li>
								<div>
									bla bla bla bla bla bla bla bla bla bla bla bla bla bla
									<a href="#" class="link1">Read More</a>
								</div>
								<span><strong class="color1">New Title 2</strong> <br>
								October 20, 2014</span>
							</li>
							<li>
								<div>
									bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla
									<a href="#"class="link1">Read More</a>
								</div>
								<span><strong class="color1">New Title 3</strong> <br>
								October 20, 2014</span>
							</li>
						  </ul>
						</div>
						<a href="#" class="up"></a>
						<a href="#" class="down"></a>
						</div>
					</div>
				</section>


			</div>

			<div class="wrapper row">
				<div class="col-3-4" >
				<h2>Services</h2>
				<section class="col-1-3">
					<div class="wrap-col">
						<h3><span class="dropcap">A</span>Shipping<span>Services</span></h3>
						<p class="pad_bot1">bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla </p>
						<a href="#" class="link1">Read More</a>
					</div>
				</section>
				<section class="col-1-3">
					<div class="wrap-col">
						<h3><span class="dropcap">B</span>Coal<span>Mining</span></h3>
						<p class="pad_bot1">bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla </p>
						<a href="#" class="link1">Read More</a>
					</div>
				</section>
				<section class="col-1-3">
					<div class="wrap-col">
						<h3><span class="dropcap">C</span>Financial<span>Consultant</span></h3>
						<p class="pad_bot1">bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla </p>
						<a href="#" class="link1">Read More</a>
					</div>
				</section>
				<section class="col-1-3">
					<div class="wrap-col">
						<h3><span class="dropcap">A</span>Shipping<span>Services</span></h3>
						<p class="pad_bot1">bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla  </p>
						<a href="#" class="link1">Read More</a>
					</div>
				</section>
				<section class="col-1-3">
					<div class="wrap-col">
						<h3><span class="dropcap">B</span>Coal<span>Mining</span></h3>
						<p class="pad_bot1">bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla </p>
						<a href="#" class="link1">Read More</a>
					</div>
				</section>
				<section class="col-1-3">
					<div class="wrap-col">
						<h3><span class="dropcap">C</span>Financial<span>Consultant</span></h3>
						<p class="pad_bot1">bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla </p>
						<a href="#" class="link1">Read More</a>
					</div>
				</section>
				</div>
				<section class="col-1-4" style="width:25%;margin:35px 0px 0px 0px;" >
					<a   height="500" data-link-color="#ccb601" class="twitter-timeline" href="https://twitter.com/DYOTees" data-widget-id="532058486108979201">Tweets by @DYOTees</a>
					<script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0],p=/^http:/.test(d.location)?'http':'https';if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src=p+"://platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");</script>
				</section>
			</div>

	</article>
<!--end of content-->
</div>