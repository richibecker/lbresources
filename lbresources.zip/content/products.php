<div class="main zerogrid">
<!-- product content -->
	<article id="content">
		<div class="wrapper">
			<h2 class="under">Supplement</h2>
			<section class="col-1-3">
			<div class="wrap-col">
				<div class="wrapper pad_bot2">
					<h3><span class="dropcap">1</span>Product name</h3>
					<figure><a href="?<?php echo md5('detailproduct'); ?>"><img src="images/product/mikei.jpg" alt=""></a></figure>
					<p class="pad_bot1">bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla </p>
					<a href="?<?php echo md5('detailproduct'); ?>" class="link1">Read More</a>
				</div>
				<div class="wrapper">
					<h3><span class="dropcap">4</span>Product name</h3>
					<figure><a href="?<?php echo md5('detailproduct'); ?>"><img src="images/product/mikei.jpg" alt=""></a></figure>
					<p class="pad_bot1">bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla .</p>
					<a href="?<?php echo md5('detailproduct'); ?>" class="link1">Read More</a>
				</div>
			</div>
			</section>
			<section class="col-1-3">
			<div class="wrap-col">
				<div class="wrapper pad_bot2">
					<h3><span class="dropcap">2</span>Product name</h3>
					<figure><a href="?<?php echo md5('detailproduct'); ?>"><img src="images/product/mikei.jpg" alt=""></a></figure>
					<p class="pad_bot1">bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla .</p>
					<a href="?<?php echo md5('detailproduct'); ?>" class="link1">Read More</a>
				</div>
				<div class="wrapper">
					<h3><span class="dropcap">5</span>Product name</h3>
					<figure><a href="?<?php echo md5('detailproduct'); ?>"><img src="images/product/mikei.jpg" alt=""></a></figure>
					<p class="pad_bot1">bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla .</p>
					<a href="?<?php echo md5('detailproduct'); ?>" class="link1">Read More</a>
				</div>
			</div>
			</section>
			<section class="col-1-3">
			<div class="wrap-col">
				<div class="wrapper pad_bot2">
					<h3><span class="dropcap">3</span>Product name</h3>
					<figure><a href="?<?php echo md5('detailproduct'); ?>"><img src="images/product/mikei.jpg" alt=""></a></figure>
					<p class="pad_bot1">bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla .</p>
					<a href="?<?php echo md5('detailproduct'); ?>" class="link1">Read More</a>
				</div>
				<div class="wrapper">
					<h3><span class="dropcap">6</span>Product name</h3>
					<figure><a href="?<?php echo md5('detailproduct'); ?>"><img src="images/product/mikei.jpg" alt=""></a></figure>
					<p class="pad_bot1">bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla .</p>
					<a href="?<?php echo md5('detailproduct'); ?>" class="link1">Read More</a>
				</div>
			</div>
			</section>
		</div>

	</article>
</div>