
<div class="main zerogrid">
<!-- content -->
	<article id="content">
		<div class="wrapper row">
			<section class="col-3-4">
				<div class="wrap-col">
					<h2 class="under">Our Location</h2>
					<!--<div id="googleMap" style="width:100%;height:380px;"></div>-->
					<iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d1983.2342982052821!2d106.78105975323231!3d-6.201746006516376!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e69f6dcc7d2c4ad%3A0x209cb1eef39be168!2sBinus+University!5e0!3m2!1sid!2sid!4v1416407843313" width="100%" height="450" frameborder="0" style="border:0"></iframe>
				</div>
			</section>
			<section class="col-1-4">
			<div class="wrap-col">
				<h2 class="under">Address</h2>
				<div id="address"><span>Country:<br>
						City:<br>
						Telephone:<br>
						Email:</span>
						Indonesia<br>
						Jakarta<br>
						021 - 1234567<br>
						<a href="mailto:" class="color2">mail@mail.com</a>
				</div>
				<h2 class="under"></h2>
				<div style="padding-left:15%">
					<a href="ymsgr:sendIM?IDYahoo">
						<img border=0 src="http://opi.yahoo.com/online?u=IDYahoo&amp;m=g&amp;t=14" />
					</a>
				</div>
			</div>
			</section>
		</div>
	</article>
</div>
