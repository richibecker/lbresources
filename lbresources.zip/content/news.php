
<div class="main zerogrid">
<!-- content -->
	<article id="content">
		<div class="wrapper tabs">
			<div class="tab-content" id="tab1">
				<h5><span class="dropcap"><strong>28</strong><span>06</span></span>News Title 1</h5>
				<div class="wrapper pad_bot2">
					<figure class="left marg_right1"><img src="images/page2_img1.jpg" alt=""></figure>
					<p class="pad_bot1">bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla </p>
					<a href="?<?php echo md5('detailnews'); ?>" class="link1">Read More</a>
				</div>
				<h5><span class="dropcap"><strong>25</strong><span>06</span></span>News Title 2</h5>
				<div class="wrapper pad_bot2">
					<figure class="left marg_right1"><img src="images/page2_img2.jpg" alt=""></figure>
					<p class="pad_bot1">bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla </p>
					<a href="?<?php echo md5('detailnews2'); ?>" class="link1">Read More</a>
				</div>
				<h5><span class="dropcap"><strong>21</strong><span>06</span></span>News Title 3</h5>
				<div class="wrapper pad_bot2">
					<figure class="left marg_right1"><img src="images/page2_img3.jpg" alt=""></figure>
					<p class="pad_bot1">bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla </p>
					<a href="?<?php echo md5('detailnews'); ?>" class="link1">Read More</a>
				</div>
			</div>
            
            <!-- tab2 -->
			<div class="tab-content" id="tab2">

				<h5><span class="dropcap"><strong>25</strong><span>06</span></span>News Title 4</h5>
				<div class="wrapper pad_bot2">
					<figure class="left marg_right1"><img src="images/page2_img2.jpg" alt=""></figure>
					<p class="pad_bot1">bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla </p>
					<a href="#" class="link1">Read More</a>
				</div>
				<h5><span class="dropcap"><strong>21</strong><span>06</span></span>News Title 5</h5>
				<div class="wrapper pad_bot2">
					<figure class="left marg_right1"><img src="images/page2_img3.jpg" alt=""></figure>
					<p class="pad_bot1">bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla </p>
					<a href="#" class="link1">Read More</a>
				</div>
				<h5><span class="dropcap"><strong>28</strong><span>06</span></span>News Title 6</h5>
				<div class="wrapper pad_bot2">
					<figure class="left marg_right1"><img src="images/page2_img1.jpg" alt=""></figure>
					<p class="pad_bot1">bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla </p>
					<a href="#" class="link1">Read More</a>
				</div>
			</div>
            
            <!-- tab3 -->
			<div class="tab-content" id="tab3">
				<h5><span class="dropcap"><strong>21</strong><span>06</span></span>News Title 7</h5>
				<div class="wrapper pad_bot2">
					<figure class="left marg_right1"><img src="images/page2_img3.jpg" alt=""></figure>
					<p class="pad_bot1">bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla </p>
					<a href="#" class="link1">Read More</a>
				</div>
				<h5><span class="dropcap"><strong>28</strong><span>06</span></span>News Title 8</h5>
				<div class="wrapper pad_bot2">
					<figure class="left marg_right1"><img src="images/page2_img1.jpg" alt=""></figure>
					<p class="pad_bot1">bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla </p>
					<a href="#" class="link1">Read More</a>
				</div>
				<h5><span class="dropcap"><strong>25</strong><span>06</span></span>News Title 9</h5>
				<div class="wrapper pad_bot2">
					<figure class="left marg_right1"><img src="images/page2_img2.jpg" alt=""></figure>
					<p class="pad_bot1">bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla </p>
					<a href="#" class="link1">Read More</a>
				</div>
			</div>
			<ul class="nav">
				<li class="selected"><a href="#tab1">1</a></li>
				<li><a href="#tab2">2</a></li>
				<li><a href="#tab3">3</a></li>
			</ul>
		</div>

	</article>
    <script type="text/javascript"> Cufon.now(); </script>
<script>
	$(document).ready(function() {
		tabs.init();
	})
</script>
</div>