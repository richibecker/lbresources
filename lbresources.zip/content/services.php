
<div class="main zerogrid">
<!-- content -->
	<article id="content">
		<div class="wrapper">

			<h2 class="under">Overview of Our Main Business Courses</h2>

			<div class="wrapper">
				<section class="col-1-3">
				<div class="wrap-col">
					<div class="wrapper pad_bot1">
						<figure class="left marg_right1"><img src="images/page3_img1.gif" alt=""></figure>
						<h6>Strategic Planning</h6>
						<p>bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla </p>
					</div>
					<div class="wrapper">
						<figure class="left marg_right1"><img src="images/page3_img2.gif" alt=""></figure>
						<h6>Risk Management</h6>
						<p>bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla </p>
					</div>
				</div>
				</section>
				<section class="col-1-3">
				<div class="wrap-col">
					<div class="wrapper pad_bot1">
						<figure class="left marg_right1"><img src="images/page3_img3.gif" alt=""></figure>
						<h6>Clients Relationship</h6>
						<p>bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla .</p>
					</div>
					<div class="wrapper">
						<figure class="left marg_right1"><img src="images/page3_img4.gif" alt=""></figure>
						<h6>Investments</h6>
						<p>bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla .</p>
					</div>
				</div>
				</section>
				<section class="col-1-3">
				<div class="wrap-col">
					<div class="wrapper pad_bot1">
						<figure class="left marg_right1"><img src="images/page3_img5.gif" alt=""></figure>
						<h6>Insurance Services</h6>
						<p>bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla .</p>
					</div>
					<div class="wrapper">
						<figure class="left marg_right1"><img src="images/page3_img6.gif" alt=""></figure>
						<h6>Sales Lead Generation</h6>
						<p>bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla .</p>
					</div>
				</div>
				</section>
			</div>

		</div>

	</article>
</div>