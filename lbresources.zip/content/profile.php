<link rel="stylesheet" type="text/css" href="css/profile-sertif.css" />
<link rel="stylesheet" type="text/css" href="css/profile-history.css" />

<script src="js/jquery-1.7.js"></script>
<script src="js/profile.js"></script>
<script src="js/jquery.timelinr-0.9.54.js"></script>
<script type="text/javascript" src="js/jquery.gallery.js"></script>

<script>
		$(function(){
			$().timelinr({
				autoPlay: 'true',
				autoPlayDirection: 'forward'
			})
		});
		$(function() {
			$('#dg-container').gallery();
			});
			$("#slideshow > div:gt(0)").hide();

setInterval(function() {
  $('#slideshow2 > div:first')
    .fadeOut(1000)
    .next()
    .fadeIn(1000)
    .end()
    .appendTo('#slideshow2');
},  3000);

</script>

<div class="main zerogrid">
<!-- content -->
	<article id="content">
<!--PROFILE START-->
<h2 class="under">Profile</h2>
	        <section id="profile-section" >


<div id="slideshow2">
   <div>
             <img id="profile-img" src="images/profile/h-1.jpg" alt="iPhone"  />
   </div>
   <div>
             <img id="profile-img" src="images/profile/ruko.jpg" alt="iPhone"  />
   </div>
</div>

<div class="copy-container">
<pre>
Lbresouces merupakan perusahaan yang bergerak di bidang jasa dan produk. sadsadas asdasdas dasdasdasd sadasdsa sadasd asdasd
sadsadsad asdsad sadasdsa asdasd sadasdas as asd aasda  sadsadasdasdas
Lbresouces merupakan perusahaan yang bergerak di bidang jasa dan produk. sadsadas asdasdas dasdasdasd sadasdsa sadasd asdasd
sadsadsad asdsad sadasdsa asdasd sadasdas as asd aasda  sadsadasdasdas

</pre>

</div>



		    </section>
<!--PROFILE END-->

<!--SERTIFIKAT START-->
<h2 class="under">Certificate</h2>
			<section id="dg-container" class="dg-container" style="margin:0px 20px 0px 20px">
				<div class="dg-wrapper">
					<a href="#"><img src="images/profile/sertifikat.jpg" alt="image05"><div>General Certificate</div></a>
					<a href="#"><img src="images/profile/sertifikat.jpg" alt="image06"><div>BP-POM Certificated</div></a>
					<a href="#"><img src="images/profile/sertifikat.jpg" alt="image07"><div>General Certificate 2</div></a>
                    <a href="#"><img src="images/profile/sertifikat.jpg" alt="image07"><div>General Certificate 3</div></a>
                    <a href="#"><img src="images/profile/sertifikat.jpg" alt="image07"><div>General Certificate 4</div></a>
                 </div>
				<nav>
					<span class="dg-prev">&lt;</span>
					<span class="dg-next">&gt;</span>
                </nav>
			</section>
<!--SERTIFIKAT END-->


   <!--HISTORY START-->
<section>

	<div id="timeline">
    <a id="timeline-title">History</a>
		<ul id="dates">
			<li><a href="#2000">2000</a></li>
			<li><a href="#2011">2011</a></li>
			<li><a href="#2014">2014</a></li>

		</ul>
		<ul id="issues">
			<li id="2000">
				<img src="images/profile/h-1.jpg" width="256" height="256" />
				<h1>2000</h1>
				<p>LBResources didirikan di hongkong. Memiliki 1000 karyawan. Didirikan oleh Mr- aaaaaaa aaaaaaaaa aaaaaaaaaaa
                aaaaaaa aaaaaaaaaa aaaaa aaaaaaaaaa aa aaaaa aaaa aaaaaaaaaaa aaaaaaaaaaa aaaaaaa aaa aaaaaaaaaaaaa, aaaa. aaa
                aaaaaaaa. aaaaaaaaaaaaaaa aaaaa aaaaaaaaaa, aaaaaa.
                aaaaa</p>
			</li>
			<li id="2011">
				<img src="images/profile/h-2.jpg" width="256" height="256" />
				<h1>2011</h1>
				<p>LBResources didirikan di hongkong. Memiliki 1000 karyawan. Didirikan oleh Mr- aaaaaaa aaaaaaaaa aaaaaaaaaaa
                aaaaaaa aaaaaaaaaa aaaaa aaaaaaaaaa aa aaaaa aaaa aaaaaaaaaaa aaaaaaaaaaa aaaaaaa aaa aaaaaaaaaaaaa, aaaa. aaa
                aaaaaaaa. aaaaaaaaaaaaaaa aaaaa aaaaaaaaaa, aaaaaa.
                aaaaa</p>
			</li>
			<li id="2014">
				<img src="images/profile/h-3.jpg" width="256" height="256" />
				<h1>2014</h1>
				<p>LBResources didirikan di hongkong. Memiliki 1000 karyawan. Didirikan oleh Mr- aaaaaaa aaaaaaaaa aaaaaaaaaaa
                aaaaaaa aaaaaaaaaa aaaaa aaaaaaaaaa aa aaaaa aaaa aaaaaaaaaaa aaaaaaaaaaa aaaaaaa aaa aaaaaaaaaaaaa, aaaa. aaa
                aaaaaaaa. aaaaaaaaaaaaaaa aaaaa aaaaaaaaaa, aaaaaa.
                aaaaa</p>
			</li>

		</ul>
		<div id="grad_left"></div>
		<div id="grad_right"></div>
		<a href="#" id="next">+</a>
		<a href="#" id="prev">-</a>
	</div>
    </section>
<!--HISTORY END-->

	</article>

</div>
